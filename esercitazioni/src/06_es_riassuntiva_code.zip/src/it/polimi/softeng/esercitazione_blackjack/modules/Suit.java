package it.polimi.softeng.esercitazione_blackjack.modules;

public enum Suit {
    DIAMONDS,
    CLUBS,
    HEARTS,
    SPADES
}
