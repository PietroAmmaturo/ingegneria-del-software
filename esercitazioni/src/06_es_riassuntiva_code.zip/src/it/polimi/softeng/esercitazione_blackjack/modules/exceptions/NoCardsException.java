package it.polimi.softeng.esercitazione_blackjack.modules.exceptions;

public class NoCardsException extends Exception {
    public NoCardsException(String s)
    {
        super(s);
    }
}
