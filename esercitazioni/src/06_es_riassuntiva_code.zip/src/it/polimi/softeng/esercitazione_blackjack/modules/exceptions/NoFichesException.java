package it.polimi.softeng.esercitazione_blackjack.modules.exceptions;

public class NoFichesException extends Exception {
    public NoFichesException(String s)
    {
        super(s);
    }
}
