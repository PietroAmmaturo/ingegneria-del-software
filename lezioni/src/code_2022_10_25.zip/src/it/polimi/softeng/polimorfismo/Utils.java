package it.polimi.softeng.polimorfismo;

public class Utils {

    public static void stampaXeY(Punto2D p) {
        System.out.println("x=" + p.getX() + ", y=" + p.getY());
    }
}
