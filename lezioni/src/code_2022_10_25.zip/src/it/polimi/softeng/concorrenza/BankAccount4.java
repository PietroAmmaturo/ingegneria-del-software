package it.polimi.softeng.concorrenza;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class BankAccount4 {
    private int balance;
    private ReadWriteLock lock;

    public BankAccount4() {
        balance = 0;
        lock = new ReentrantReadWriteLock();
    }

    public void withdraw(int amount) {
        lock.writeLock().lock();
        balance -= amount;
        lock.writeLock().unlock();
    }

    public void deposit(int amount) {
        lock.writeLock().lock();
        balance += amount;
        lock.writeLock().unlock();
    }

    public int getBalance() {
        lock.readLock().lock();
        int returnVal = balance;
        lock.readLock().unlock();
        return returnVal;
    }
}
