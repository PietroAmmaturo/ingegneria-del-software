package it.polimi.softeng.generics;

public class DifferentPair<T, U> {
    private final T first;
    private final U second;

    public DifferentPair(T first, U second) {
        this.first = first;
        this.second = second;
    }

    public T getFirst() {
        return first;
    }

    public U getSecond() {
        return second;
    }
}
