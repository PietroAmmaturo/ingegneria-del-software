package it.polimi.softeng.exceptions;

public class CourseInfo {
    private String name;
    private int voto;

    public CourseInfo(String name, int voto) {
        this.name = name;
        this.voto = voto;
    }

    public String getName() {
        return name;
    }

    public int getVoto() {
        return voto;
    }
}
