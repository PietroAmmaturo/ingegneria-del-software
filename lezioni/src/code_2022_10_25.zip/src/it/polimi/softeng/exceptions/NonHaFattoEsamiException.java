package it.polimi.softeng.exceptions;

public class NonHaFattoEsamiException extends Exception {
}
