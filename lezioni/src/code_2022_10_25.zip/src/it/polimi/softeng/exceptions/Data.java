package it.polimi.softeng.exceptions;

public class Data {
    private int giorno;
    private int mese;
    private int anno;

    public Data(int giorno, int mese, int anno) {
        this.giorno = giorno;
        this.mese = mese;
        this.anno = anno;
    }

    public Data(int mese, int anno) {
        if (mese < 1 || mese > 12) {
            this.mese = 1;
        } else {
            this.mese  = mese;
        }
    }

    public Data(int anno) {
        this(1, anno);
    }

    public int getGiorno() {
        return this.giorno;
    }

    public int getMese() {
        return this.mese;
    }

    public int getAnno() {
        return anno;
    }

    public void setGiorno(int giorno) {
        this.giorno = giorno;
    }

    public void capodanno() {
        giorno = 1;
        mese = 1;
        anno = anno + 1;
    }
}
