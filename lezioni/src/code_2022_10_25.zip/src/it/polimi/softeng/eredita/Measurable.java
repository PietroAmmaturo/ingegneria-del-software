package it.polimi.softeng.eredita;

public interface Measurable {

    public int measure();
}
