package it.polimi.softeng.exercises.concorrenza.ex20190218;

import java.util.ArrayList;
import java.util.List;

public class Stats {
    private final List<Activity> activities;
    private final List<Nutrient> nutrients;

    public Stats() {
        activities = new ArrayList<>();
        nutrients = new ArrayList<>();
    }
}

class Activity {
    public int getCalories() {
        return 0;
    }
}

class Nutrient {
    public int getCalories() {
        return 0;
    }
}
