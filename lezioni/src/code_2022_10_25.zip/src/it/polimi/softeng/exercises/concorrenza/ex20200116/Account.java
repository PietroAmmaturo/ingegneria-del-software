package it.polimi.softeng.exercises.concorrenza.ex20200116;

import java.util.ArrayList;
import java.util.List;

public class Account {
    private static List<Double> log = new ArrayList<Double >();
    private double balance ;

    public Account() {
        balance = 0.0;
    }

    public synchronized void deposit(double val) {
        balance += val;
        log.add(val);
    }

    public synchronized void withdraw(double val) {
        balance -= val;
        log.add(-val);
    }

}

