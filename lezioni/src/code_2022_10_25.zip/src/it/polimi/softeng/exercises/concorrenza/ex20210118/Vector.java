package it.polimi.softeng.exercises.concorrenza.ex20210118;

public class Vector {
    private double x;
    private double y;
    public Vector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public Vector sum(Vector other) {
        Vector res = new Vector(this.x + other.x,this.y+other.y);
        return res ;
    }
}
