package it.polimi.softeng.pattern.adapter;

public class TextFile implements Printable {
    @Override
    public void print(int size) {
        // Code to print ...
    }
}
