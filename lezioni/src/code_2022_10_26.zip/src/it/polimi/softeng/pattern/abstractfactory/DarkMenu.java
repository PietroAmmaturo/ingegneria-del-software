package it.polimi.softeng.pattern.abstractfactory;

public class DarkMenu extends Menu {
}
