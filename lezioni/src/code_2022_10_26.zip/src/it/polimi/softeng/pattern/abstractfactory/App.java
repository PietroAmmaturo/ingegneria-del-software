package it.polimi.softeng.pattern.abstractfactory;

public class App {
    // Change visibility if needed
    private Menu menu;
    private Window window;

    // TODO
    public void initApp() {
        // Initializes the menu and the window
    }

    public void useWindow() {
        // Does something with window
    }

    public void useMenu() {
        // Does something with menu
    }
}
