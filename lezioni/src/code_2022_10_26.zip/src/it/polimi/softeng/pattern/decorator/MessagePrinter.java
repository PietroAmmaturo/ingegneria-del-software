package it.polimi.softeng.pattern.decorator;

public class MessagePrinter {
    public void print(String message) {
        System.out.println(message);
    }
}
