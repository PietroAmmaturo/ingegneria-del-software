package it.polimi.softeng.pattern.adapter;

// Class to manage PDF files (from an external library)
public class LibPDFFile {

    // Print the PDF file with the given size
    // Size from 0 to 20
    public void stampa(int size) {

    }
}
