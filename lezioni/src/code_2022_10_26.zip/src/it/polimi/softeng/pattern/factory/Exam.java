package it.polimi.softeng.pattern.factory;

public class Exam {
}
