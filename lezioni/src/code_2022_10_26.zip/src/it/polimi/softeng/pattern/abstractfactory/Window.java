package it.polimi.softeng.pattern.abstractfactory;

public class Window {
}
