package it.polimi.softeng.pattern.factory;

public class Student {

    // TODO!
    public Exam produceExam() {
        // Create exam (depending on the type of student)
        // ... Do something with exam ...

        // Return the exam for evaluation
        return null;
    }

}
