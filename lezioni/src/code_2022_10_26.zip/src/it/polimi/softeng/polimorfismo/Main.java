package it.polimi.softeng.polimorfismo;

public class Main {
    public static void main(String[] args) {
        Punto2D x = new Punto2D(0,0);
        Punto2D y = new Punto3D(0,0, 0);
        Punto3D z = new Punto3D(0, 0, 0);
        // Errore! Punto3D w = new Punto2D();

        x.distanza(x);
        x.distanza(y);
        x.distanza(z);

        y.distanza(x);
        y.distanza(y);
        y.distanza(z);

        z.distanza(x);
        z.distanza(y);
        z.distanza(z);

        Utils.stampaXeY(x);
        Utils.stampaXeY(y);
        Utils.stampaXeY(z);
    }


}
