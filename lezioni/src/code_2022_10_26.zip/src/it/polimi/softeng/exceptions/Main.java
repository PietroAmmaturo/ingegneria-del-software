package it.polimi.softeng.exceptions;

public class Main {
    public static void main(String[] args) {
        Student s = new Student("Ale");
        try {
            System.out.println("Pippo");
            float media = s.getMedia();
            System.out.println("Pluto");
        } catch (NonHaFattoEsamiException e) {
            System.out.println("Non aveva fatto esami");
        } finally {
            System.out.println("Comunque finisco qui");
        }
    }

}