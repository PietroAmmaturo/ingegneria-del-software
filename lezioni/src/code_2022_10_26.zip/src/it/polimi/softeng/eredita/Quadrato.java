package it.polimi.softeng.eredita;

public class Quadrato extends Poligono {

    public Quadrato() {
        super(4);
        this.numLati = 5;
    }
}
