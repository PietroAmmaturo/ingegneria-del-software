package it.polimi.softeng.eredita;

public class Cerchio extends Figura {
}
