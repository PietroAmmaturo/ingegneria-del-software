package it.polimi.softeng.generics;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Pair<String> p = new Pair<String>("Pippo", "Pluto");
        Pair<Integer> p1 = new Pair<>(10, 20);
        Pair<Double> p2 = new Pair<>(10.0, 20.2);

        DifferentPair<String, Integer> d1 = new DifferentPair<>("Pippo", 10);

        List<String> a = new ArrayList<>();
        a.add("aaa");
        a.get(0);

        List<String> a1 = new LinkedList<>();

        Set<String> a2 = new HashSet<>();
        a2.add("Ciao");
        a2.add("Ciao");
        a2.add("Ciao");
        System.out.println(a2.size());

        Map<String, Integer> m = new HashMap<>();
        m.put("Nome", 12345);
        int tel = m.get("Nome");

        Iterator<String> it = a1.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }

        for (String s : a1) {
            System.out.println(s);
        }

        Pair<String> pp = new Pair<>("A", "B");

        // Esplicito
        Iterator<String> ppIt = pp.iterator();
        while (ppIt.hasNext()) {
            System.out.println(ppIt.next());
        }

        // Implicito, definito da Java (è equivalente a quello sopra)
        for (String s : pp) {
            System.out.println(s);
        }
















    }
}
