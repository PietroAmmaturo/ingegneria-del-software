package it.polimi.softeng.collections;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Set<String> s1 = new HashSet<>();
        s1.add("Pippo");
        s1.add("Pluto");
        boolean res = s1.contains("Pippo");
        int size = s1.size();
        s1.remove("Pippo");

        Set<Object> s2 = new HashSet<>();
        s2.add("Pippo");

        for (String s : s1) {
            System.out.println(s);
        }

        List<String> l1 = new ArrayList<>();
        l1.add("Pippo");
        l1.set(0, "Pluto");
        String res1 = l1.get(0);

        for (String l : l1) {
            System.out.println(l);
        }

        Map<String, Integer> m1 = new HashMap<>();
        m1.put("Ale", 34909);
        m1.put("Pippo", 123);
        // Sovrascrivo il numero telefonico di Pippo
        m1.put("Pippo", 234);
        int numeroDiPippo = m1.get("Pippo");

        for (String s : m1.keySet()) {
            System.out.println("Key: " + s + ", value: " + m1.get(s));
        }

        for (Map.Entry<String, Integer> e : m1.entrySet()) {
            System.out.println("Key: " + e.getKey()  + ", value: " + e.getValue());
        }

    }
}
