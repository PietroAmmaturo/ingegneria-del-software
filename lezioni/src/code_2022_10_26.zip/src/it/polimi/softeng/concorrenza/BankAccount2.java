package it.polimi.softeng.concorrenza;

public class BankAccount2 {
    private int balance;

    public synchronized void withdraw(int amount) throws InterruptedException {
        while (amount > balance) {
            this.wait();
        }
        balance -= amount;
        this.notifyAll();
    }

    // Assumo che amount sia < 1000
    public synchronized void deposit(int amount) throws InterruptedException {
        while (balance + amount > 1000) {
            this.wait();
        }
        balance += amount;
        this.notifyAll();
    }

    public synchronized int getBalance() {
        return balance;
    }
}
