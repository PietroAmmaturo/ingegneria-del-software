package it.polimi.softeng.concorrenza;

public class BankAccount {
    private int balance;

    public void withdraw(int amount) {
        synchronized (this) {
            balance -= amount;
        }
    }

    public synchronized void deposit(int amount) {
        balance += amount;
    }

    // Esempio di deadlock!
    public synchronized void transfer(int amount, BankAccount destination) {
        balance -= amount;
        synchronized (destination) {
            destination.balance += amount;
        }
        // Codice sopra equivalente a questo
        // balance -= amount;
        // destination.deposit(amount);
    }

    public void transferSenzaDeadlock(int amount, BankAccount destination) {
        synchronized (this) {
            balance -= amount;
        }
        synchronized (destination) {
            destination.balance += amount;
        }
        // Codice sopra equivalente a questo
        // this.withdraw(amount);
        // destination.deposit(amount);
    }

    public synchronized int getBalance() {
        return balance;
    }
}
