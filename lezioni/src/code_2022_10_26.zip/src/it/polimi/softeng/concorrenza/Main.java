package it.polimi.softeng.concorrenza;

import java.util.*;
import java.util.concurrent.*;

public class Main {
    public static void main(String[] args) throws InterruptedException, ExecutionException {
        for (int i=0; i<1000; i++) {
            Thread t = new MyThread1(i);
            t.start();
        }
        System.out.println("Ciao");
        for (int i=0; i<1000; i++) {
            Runnable r = new MyRunnable1(i);
            Thread t = new Thread(r);
            t.start();
        }
        System.out.println("Ciao ancora");
        for (int i=0; i<1000; i++) {
            final int num = i;
            Runnable r = () -> System.out.println(num);
            Thread t = new Thread(r);
            t.start();
        }

        final BankAccount account = new BankAccount();
        Thread t1 = new Thread(() -> {
            for (int i=0; i<1000; i++) {
                account.deposit(1);
            }
        });
        Thread t2 = new Thread(() -> {
            for (int i=0; i<1000; i++) {
                account.withdraw(1);
            }
        });

        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println("Final value: " + account.getBalance());

        ExecutorService executorService = Executors.newCachedThreadPool();
        Future<Integer> resultFuture = executorService.submit(() -> 2 + 2);
        Future<String> resultStringFuture = executorService.submit(() -> "Ciao");
        System.out.println("Conduco la mia vita da main");
        int result = resultFuture.get();
        String resultString = resultStringFuture.get();
        executorService.shutdown();

        Map<String, Integer> m = new ConcurrentHashMap<>();
        Queue<Integer> queue = new ArrayBlockingQueue<>(4);
        List<Integer> listaNonSync = new ArrayList<>();
        List<Integer> listaSync = Collections.synchronizedList(listaNonSync);


    }
}

class MyThread1 extends Thread {
    private final int num;

    public MyThread1(int num) {
        this.num = num;
    }

    @Override
    public void run() {
        System.out.println(num);
    }
}

class MyRunnable1 implements Runnable {
    private final int num;

    public MyRunnable1(int num) {
        this.num = num;
    }

    @Override
    public void run() {
        System.out.println(num);
    }
}
